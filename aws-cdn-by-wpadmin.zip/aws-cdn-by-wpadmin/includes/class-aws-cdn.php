<?php
class wpaawscdn
{
	public function __construct()
	{
	if ( ! defined( 'wpawscdnbasedir' ) ) define( 'wpawscdnbasedir', plugin_dir_path( __FILE__ ) );
	if ( ! defined( 'wpawscdnurl' ) ) define( 'wpawscdnurl', plugin_dir_url( __FILE__ ) );
	if ( ! defined( 'wpawscdnver' ) ) define( 'wpawscdnver', '2.0.0');
	if ( ! defined( 'wpawscdnname' ) ) define( 'wpawscdnname', 'aws-cdn-by-wpadmin');
	if ( ! defined( 'wpawscdnfilename' ) ) define( 'wpawscdnfilename', 'aws-cdn-by-wpadmin.php');
	if ( ! defined( 'wpawscdnbasename' ) ) define( 'wpawscdnbasename', 'aws-cdn-by-wpadmin/aws-cdn-by-wpadmin.php');
	add_action('wp_footer', 'comment_in_footer');
	function comment_in_footer()
	{
		echo "<!--Amazon AWS CDN Plugin. Powered by WPAdmin.ca " . wpawscdnver ."-->";
	}
		
	function wpadmin_add_settings_link( $links )
	{
		$forum_link = '<a target=_BLANK href="https://wordpress.org/support/plugin/aws-cdn-by-wpadmin/">' . __( 'Support' ) . '</a>';
		array_unshift( $links, $forum_link );
		$review_link = '<a target=_BLANK href="https://wordpress.org/support/plugin/aws-cdn-by-wpadmin/reviews/#new-post">' . __( 'Review' ) . '</a>';
		array_unshift( $links, $review_link );
		$donate_link = '<a target=_BLANK href="https://wpadmin.ca/donation/">' . __( '<b><i>Buy Me a Coffee</i></b>' ) . '</a>';
		array_unshift( $links, $donate_link );
		$settings_link = '<a href="admin.php?page=wpa-aws-setup">' . __( 'Setup' ) . '</a>';
		array_unshift( $links, $settings_link );
		return $links;
	}
	add_filter( "plugin_action_links_" . wpawscdnbasename, 'wpadmin_add_settings_link' );
	}
	
	
	public function load()
	{
		require wpawscdnbasedir. 'admin/class-aws-cdn-admin.php';
	}
	
	
	function console_log($output, $with_script_tags = true)
	{
	$js_code = 'console.log(' . json_encode($output, JSON_HEX_TAG) . ');';
	if ($with_script_tags) $js_code = '<script>' . $js_code . '</script>';
	echo $js_code;
	}

}
$wpaawscdn = new wpaawscdn;
$wpaawscdn->load();
