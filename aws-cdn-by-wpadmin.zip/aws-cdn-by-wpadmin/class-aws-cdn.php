<?php
register_activation_hook( __FILE__, ['wpawscdn','wpaawscdn_activate'] );
register_deactivation_hook( __FILE__, ['wpawscdn','wpaawscdn_deactivate'] );

add_action( 'plugins_loaded', ['wpawscdn','init'] );
	
class wpawscdn
{

protected static $instance;

	public function __construct()
	{
	if ( ! defined( 'wpawscdnbasedir' ) ) define( 'wpawscdnbasedir', plugin_dir_path( __FILE__ ) );
	if ( ! defined( 'wpawscdnurl' ) ) define( 'wpawscdnurl', plugin_dir_url( __FILE__ ) );
	if ( ! defined( 'wpawscdnver' ) ) define( 'wpawscdnver', '2.0.0');
	if ( ! defined( 'wpawscdnname' ) ) define( 'wpawscdnname', 'aws-cdn-by-wpadmin');
	if ( ! defined( 'wpawscdnfilename' ) ) define( 'wpawscdnfilename', 'aws-cdn-by-wpadmin.php');
	if ( ! defined( 'wpawscdnbasename' ) ) define( 'wpawscdnbasename', 'aws-cdn-by-wpadmin/aws-cdn-by-wpadmin.php');
	
	add_action( 'plugins_loaded', ['wpawscdn', 'init'] );
	
	add_action('wp_footer', 'wpawscdn_comment_in_footer');	
	function wpawscdn_comment_in_footer()
	{
		echo "<!--Amazon AWS CDN Plugin. Powered by WPAdmin.ca " . wpawscdnver ."-->";
	}
		
	function wpawscdn_add_settings_link( $links )
	{
		$forum_link = '<a target=_BLANK href="https://wordpress.org/support/plugin/aws-cdn-by-wpadmin/">' . __( 'Support' ) . '</a>';
		array_unshift( $links, $forum_link );
		$review_link = '<a target=_BLANK href="https://wordpress.org/support/plugin/aws-cdn-by-wpadmin/reviews/#new-post">' . __( 'Review' ) . '</a>';
		array_unshift( $links, $review_link );
		$donate_link = '<a target=_BLANK href="https://wpadmin.ca/donation/">' . __( '<b><i>Buy Me a Coffee</i></b>' ) . '</a>';
		array_unshift( $links, $donate_link );
		$settings_link = '<a href="admin.php?page=wpa-aws-setup">' . __( 'Setup' ) . '</a>';
		array_unshift( $links, $settings_link );
		return $links;
	}
	add_filter( "plugin_action_links_" . wpawscdnbasename, 'wpawscdn_add_settings_link' );
	}
	
	public static function init()
	{
	}

	public function load()
	{
	require wpawscdnbasedir. 'admin/class-aws-cdn-admin.php';
	}
	
	public static function wpaawscdn_activate()
	{
	add_option('wpawscdndata', 'NA', '', $this->autoload);
	add_option('wpawscdndomain', 'NA', '', $this->autoload);
	add_option('WPAdmin_CDN_Ignorelist', 'NA', '', $this->autoload);
	add_option('WPAdmin_CDN_Ignorepages', 'NA', '', $this->autoload);
	}
	
	public static function wpaawscdn_deactivate()
	{
	delete_option('wpawscdndata');
	delete_option('wpawscdndomain');
	}
	
	public function wpaws_cdn_prefetch()
	{
	if(get_option('wpawscdnisactive') && (stristr(get_option('wpawscdnisactive'),'cloudfront') || stristr(get_option('wpawscdnisactive'), str_replace("www.","",$_SERVER['HTTP_HOST']) )) )
		{
		$cdndomain = get_option('wpawscdnisactive');
		echo "<link rel='dns-prefetch' href='//$cdndomain' />";
		}
	}
	
	public function wpaws_cdn_content($content)
	{
		if(get_option('WPAdmin_CDN_Ignorepages'))
                {
                $pages = get_option('WPAdmin_CDN_Ignorepages');
		$currenturi = explode("/",$_SERVER['REQUEST_URI']);
		$currenturi = array_filter($currenturi);
		$currenturi = $currenturi[count($currenturi)];
                if(stristr($pages,$currenturi)) return $content;
                
		        /*if currenturi is blank check if homepage*/
		        if($currenturi == "")
		        {
		        $wpawscdn_homepageid = get_option( 'page_on_front' );
		        $wpawscdn_homepageslug = get_post_field('post_name',$wpawscdn_homepageid);
		        if(stristr($pages,$wpawscdn_homepageslug)) return $content;
		        }
		}

		if(get_option('wpawscdnisactive') && (stristr(get_option('wpawscdnisactive'),'cloudfront') || stristr(get_option('wpawscdnisactive'), str_replace("www.","",$_SERVER['HTTP_HOST']) )) )
		{
		$cdndomain = get_option('wpawscdnisactive');
		$serverproto = "http";
			if(@$_SERVER['HTTPS'] == "on") $serverproto = "https";
		$localdomain = $serverproto . "://" . $_SERVER['HTTP_HOST'];
		$altdomain = "//" . $_SERVER['HTTP_HOST'];
		$cfcdndomain =  $serverproto . "://" . $cdndomain;
		$altcfcdndomain = "//" .  $cdndomain;
		$dummydomain = strrev($localdomain);
		$altdummydomain = strrev($altdomain);
		/*replace the links*/
			if(gettype($content) == "string")
			{
				if( strstr($content,'href') )
				{
				$content = str_replace('href="' . $localdomain,'href="' . $dummydomain,$content);
				$content = str_replace('href="' . $altdomain,'href="' . $altdummydomain,$content);
				$content = str_replace("href='" . $localdomain,"href='" . $dummydomain,$content);
				$content = str_replace("href='" . $altdomain,"href='" . $altdummydomain,$content);				
				}
				}
			elseif(gettype($content) == "array")
			{
				if( in_array('href',$content) )
				{
				$content = str_replace('href="' . $localdomain,'href="' . $dummydomain,$content);
				$content = str_replace('href="' . $altdomain,'href="' . $altdummydomain,$content);
				$content = str_replace("href='" . $localdomain,"href='" . $dummydomain,$content);
				$content = str_replace("href='" . $altdomain,"href='" . $altdummydomain,$content);				
				}
			
			}
		$content = str_replace($localdomain,$cfcdndomain,$content);
		$content = str_replace($altdomain,$altcfcdndomain,$content);

		/*get exclusions and revert*/
		if(get_option('WPAdmin_CDN_Ignorelist'))
		{
		$exclusionlist = get_option('WPAdmin_CDN_Ignorelist');
		$exlist = explode(",",$exclusionlist);
		$exlist = array_filter($exlist);	
			foreach($exlist as $exl)
			{
				if(gettype($content) == "string")
				{
					if( strstr($content,$exl) )
					{
					$content = str_replace($cfcdndomain,$localdomain,$content);
					$content = str_replace($altcfcdndomain,$altdomain,$content);
					}
				}
				elseif(gettype($content) == "array")
				{
					if( in_array($exl,$content) )
					{
					$content = str_replace($cfcdndomain,$localdomain,$content);
					$content = str_replace($altcfcdndomain,$altdomain,$content);
					}
				
				}
			}
		}
		$content = str_replace('href="' . $dummydomain,'href="' . $localdomain,$content);
		$content = str_replace('href="' . $altdummydomain,'href="' . $altdomain,$content);
		$content = str_replace("href='" . $dummydomain,"href='" . $localdomain,$content);
		$content = str_replace("href='" . $altdummydomain,"href='" . $localdomain,$content);	
		}
			return $content;
	}
	
}

$wpawscdn = new wpawscdn;
$wpawscdn->load();

add_action('wp_head',array($wpawscdn,'wpaws_cdn_prefetch'),-1);

if( !is_admin() ){
add_filter('the_content',array($wpawscdn,'wpaws_cdn_content'),PHP_INT_MAX);
add_filter( 'style_loader_src', array($wpawscdn,'wpaws_cdn_content') ,PHP_INT_MAX);
add_filter( 'script_loader_src', array($wpawscdn,'wpaws_cdn_content') ,PHP_INT_MAX);
add_filter( 'woocommerce_product_get_image', array($wpawscdn,'wpaws_cdn_content'),PHP_INT_MAX);	
add_filter( 'wp_get_attachment_thumb_url', array($wpawscdn,'wpaws_cdn_content'),PHP_INT_MAX);
add_filter( 'wp_get_attachment_url', array($wpawscdn,'wpaws_cdn_content'),PHP_INT_MAX);
add_filter( 'wp_get_attachment_link', array($wpawscdn,'wpaws_cdn_content'),PHP_INT_MAX);
add_filter('render_block',array($wpawscdn,'wpaws_cdn_content'),PHP_INT_MAX);
add_filter( 'wp_get_attachment_image', array($wpawscdn,'wpaws_cdn_content'),PHP_INT_MAX);
add_filter( 'wp_get_attachment_image_attributes', array($wpawscdn,'wpaws_cdn_content'),PHP_INT_MAX);
add_filter( 'wp_get_attachment_image_srcset', array($wpawscdn,'wpaws_cdn_content'),PHP_INT_MAX);
add_filter( 'wp_get_attachment_thumb_file', array($wpawscdn,'wpaws_cdn_content'),PHP_INT_MAX);
add_filter( 'post_thumbnail_html', array($wpawscdn,'wpaws_cdn_content') ,PHP_INT_MAX);
add_filter( 'widget_text', array($wpawscdn,'wpaws_cdn_content'),PHP_INT_MAX);
add_filter( 'post_gallery', array($wpawscdn,'wpaws_cdn_content'),PHP_INT_MAX);
add_filter( 'wp_calculate_image_srcset', array($wpawscdn,'wpaws_cdn_content'),PHP_INT_MAX);
}


