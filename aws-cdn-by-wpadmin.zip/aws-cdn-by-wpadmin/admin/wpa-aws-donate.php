<?php
$wpa_cdnkey =  get_option("WPAdmin_CDN_KEY"); 
if($wpa_cdnkey == "Blank") $wpa_cdnkey = "";
?>

<h1>Support AWS CDN</h1>
<div class='gscontainer'>
<div class='gsrow'>
<div class='gscols12'>
<P>Thank you for using our plugin and supporting future development by making a donation. Your appreciation of our plugin helps us enhance it for the open source community. When you make a donation, your Name will be added to our Donor's list on <a href='https://wpadmin.ca/free-wordpress-plugin-amazon-cloudfront-cdn/' target=_BLANK>The Plugin Page on WPAdmin.ca</a></p>

<p>
<a class='gsformbtn' href='https://wpadmin.ca/donation/' target=_BLANK>Buy us a Coffee</a>
</p>
</div>

</div>
</div>
