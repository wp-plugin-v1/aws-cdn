<?php
if(get_option('wpawscdndata'))
{
	$wpawscdndata = get_option('wpawscdndata');
	$accessid = $wpawscdndata['accessid'];
	$minttl = $wpawscdndata['minttl'];
	$maxttl = $wpawscdndata['maxttl'];
	$secretkey = $wpawscdndata['secretkey'];
	$subfolder = $wpawscdndata['subfolder'];
/*	if($wpawscdndata['verifymethod'] == "EMAIL")
	{
	$dnsselected = "";
	$emailselected = "checked";	
	}*/
	if($wpawscdndata['custom'] == "Yes")
	{
		$custom = "Checked";
		$wpawscdndomain = $wpawscdndata['customdomain'];
		$type='text';
	}
	$customdomain = $wpawscdndata['customdomain'];
	if($wpawscdndata['priceclass'] == "PriceClass_100") $selected1 = "Selected";
	if($wpawscdndata['priceclass'] == "PriceClass_200") $selected2 = "Selected";
	if($wpawscdndata['priceclass'] == "PriceClass_All") $selected3 = "Selected";
}
?>

<h1>Setup Amazon Cloudfront CDN</h1>

<div class=gscontainer>
<div class=gsrow>

<div class='gscols12'>
<div id='wpawscdnresult'></div>
</div>

<div class='gscols3'>
<label>Domain Name<br>
<input type=text id=wpawscdndomain value="<?php echo $this->wpawscdndomain;?>" class=gsforminput>
</label>
</div>

<div class='gscols3'>
<label>Access ID<br>
<input type=text id=wpawscdnaccessid value="<?php echo $accessid; ?>" class=gsforminput>
</label>
</div>

<div class='gscols3'>
<label>Secret Key<br>

<input type=text id=wpawscdnsecretkey value="<?php echo $secretkey; ?>" class=gsforminput>
</label>
</div>

<div class='gscols3'>
<label>Min. Cache time in seconds<br>
<input type=number min=3600 max=86400 id=wpawscdnminttl value="<?php echo $minttl; ?>" class=gsforminput>
</label>
</div>

<div class='gscols3'>
<label>Max. Cache time in seconds<br>
<input type=text min=3600 max=2592000 id=wpawscdnmaxttl value="<?php echo $maxttl; ?>" class=gsforminput>
</label>
</div>

<div class='gscols3'>
<label>Price Class<br>
<select id="wpawscdnpriceclass" class="gsforminput" placeholder="Price Class">	
<option <?php echo $selected1; ?> value="PriceClass_100">US, Canada and Europe</option>
<option <?php echo $selected2; ?> value="PriceClass_200">US, Canada, Europe &amp; Asia</option>
<option <?php echo $selected3; ?> value="PriceClass_All">All Locations</option>
</select>
</label>
</div>

<div class='gscols6'>
<label>Domain hosted in a sub-folder<br>
<input type=text id=wpawscdnsubfolder value="<?php echo $subfolder; ?>" class=gsforminput>
</label>
</div>

<div class='gscols6'>
&nbsp;<br>
<label><input type=checkbox <?php echo $custom; ?> id=wpawscdnusecdn data-cdn='<?php echo $wpawscdndomain;?>' name=wpawscdnusecdn > &nbsp; I would like to use a custom CDN domain
</label>
</div>

<div class='gscols3 certblock'>
<label>Custom CDN domain<br>
<input type=<?php echo $type; ?> id=wpawscdncustomdomain value="<?php echo $wpawscdndomain;?>" class=gsforminput>
</label>
</div>

<div class='gscols6 certblock'>
<?php
if(get_option('wpawscdnarn') && get_option('wpawscdnarn') != "NA")
{
echo "<label>Certificate ARN<br>";
echo "<input type=text READONLY id=wpawscdncertarn value=" . get_option('wpawscdnarn') . " class=gsforminput>";
echo "</label>";
}
else
{
echo "<p class=gstextcenter>&nbsp;<br><a href='/wp-admin/admin.php?page=wpa-aws-ssl' class='gsformbtn'>Request a Certificate First</a></p>";
}
?>
</div>


<div id=wpawscdnnote class='gscols12 gshidden'>
<input type=hidden id=wpawscdnAWSID value=''>
<p><b>NOTE</b>: This feature needs an SSL certificate. The plugin will request a <b>Free</b> certificate from <a href='https://aws.amazon.com/certificate-manager/pricing/' target=_BLANK>Amazon Certificate Manager (ACM)</a>.</p></div>

<div class='gscols3'>
<input type=button id=wpawscdncreate value="Create Distribution" class=gsformbtn>
</div>

<div class='gscols3'>
<input type=button id=wpawscdnlist value="List Distribution" class=gsformbtn>
</div>


<div class='gscols3'>
<input type=button id=wpawscdnmodify value="Modify Distribution" class=gsformbtn>
</div>

<div class='gscols12'>
<p>
<a target=_BLANK href='https://wpadmin.ca/how-to-create-an-aws-user-with-limited-permissions-to-access-cloudfront-only/'>How to create an Amazon user with the correct permission</a>
</p>
</div>

</div>
</div>
