<?php 
$wpawscdnsubfolder = content_url();
$wpa_these = array("http:","https:","/","wp-content",$this->wpawscdndomain);
$wpawscdnsubfolder = str_replace($wpa_these,"",$wpawscdnsubfolder);
if($wpawscdnsubfolder == null) $subfolder = false;

$accessid = $secretkey = $priceclass = $subfolder = $custom = $customdomain = $selected1 = $selected2 = $selected3 = '';
$minttl = 3600;
$maxttl = 86400;
$type = 'hidden';
$dnsselected = "checked";
$emailselected = "";
$wpawscdndomain = 'cdn.' . str_replace('www.','',$this->wpawscdndomain);

if($this->wpawscloudfront)
{
require(wpawscdnbasedir . 'admin/wpa-aws-configure.php');
}
else
{
require(wpawscdnbasedir . 'admin/wpa-aws-deploy.php');
}

